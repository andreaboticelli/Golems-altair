import React from 'react';
import GolemPage from '../components/GolemPage';

const Homunculus: React.FC = () => {
  return <GolemPage type="aether" title="Homunculus (Aether)" />;
};

export default Homunculus;
